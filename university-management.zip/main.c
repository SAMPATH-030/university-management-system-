#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <time.h>

// Constants for Library Management
#define MAX_BOOKS 1000
#define MAX_STUDENTS 1000
#define MAX_ISSUES 500
#define PASSWORD "lib123"

// Constants for Student/Faculty Management
#define MAX_SUBJECTS 10
#define MAX_FACULTY 30

// Structures for Lab Management
struct Lab {
    int labId;
    char labName[50];
};

struct Machine {
    int machineId;
    int labId;
    char status[20]; // Available / In Use / Under Maintenance
    char specification[100];
};

// Structures for Library Management
struct Book {
    int id;
    char title[100];
    char author[50];
    char publisher[50];
    int year;
    int copies;
    int available;
    char category[30];
};

struct LibStudent {
    char roll_number[15];
    char name[50];
};

struct Issue {
    int book_id;
    char roll_number[15];
    char issue_date[20];
    char due_date[20];
    char return_date[20];
    float fine;
};

// Structures for Student/Faculty Management
struct Student {
    int id;
    char name[50];
    char father_name[50];
    char father_phone[15];
    char student_phone[15];
    char aadhar_number[20];
    char quota[20];         // RTF or Management
    char course[30];        // CSE, ECE, Civil, Mechanical
    char accommodation[20]; // Bus or Hostel
    float total_fees;
    float fee_paid;
    float fee_balance;
    char roll_number[15];
    char last_payment_date[20];
    
    // New fields for attendance and marks
    int num_subjects;
    char subjects[MAX_SUBJECTS][50];
    int attendance[MAX_SUBJECTS]; // Percentage
    float marks[MAX_SUBJECTS];    // Marks out of 100
};

struct Faculty {
    int id;
    char name[50];
    char degree[30];
    char phone[15];
    char subjects[100];  // Comma-separated subjects
    float basic_salary;
    float hra;
    float da;
    float ta;
    float deductions;
    float net_salary;
    char room_number[10];
    char faculty_code[15]; // Format: 24NSD1A000
    char joining_date[20];
    char last_salary_date[20];
};

// Global variables for Library Management
struct Book books[MAX_BOOKS];
struct LibStudent libStudents[MAX_STUDENTS];
struct Issue issues[MAX_ISSUES];
int bookCount = 0;
int libStudentCount = 0;
int issueCount = 0;

// Global variables for Student/Faculty Management
struct Student students[MAX_STUDENTS];
int studentCount = 0;

struct Faculty faculty[MAX_FACULTY];
int facultyCount = 0;

// Function prototypes for Lab Management
void labManagementMenu();
void addLab();
void viewLabs();
void addMachine();
void viewMachinesByLab();
void searchMachineById();
void deleteMachine();

// Function prototypes for Library Management
void libraryMenu();
void addBook();
void searchBook();
void displayBook(int index);
void issueBook();
void returnBook();
void viewIssues();
void generateReports();
int authenticate();
void getCurrentDate(char *dateStr);
void calculateDueDate(const char *issueDate, char *dueDate);
float calculateFine(const char *dueDate, const char *returnDate);

// Function prototypes for Student Management
void addStudent();
void generateBill(struct Student s);
void studentManagement();
void viewStudents();
void payFees();
void viewFeeReport();
void manageAttendance();
void manageMarks();
void viewAttendanceReport();
void viewMarksReport();

// Function prototypes for Faculty Management
void addFaculty();
void viewFaculty();
void facultyManagement();
void generateFacultyCode(char *code, int count);
void calculateSalary(struct Faculty *f);
void paySalary();
void salaryReport();
void salarySlip(struct Faculty f);

// Common functions
void getCurrentDateCommon(char *dateStr);

// Lab Management Functions
void labManagementMenu() {
    int choice;

    do {
        printf("\n===== Lab Management System =====\n");
        printf("1. Add Lab\n");
        printf("2. Add Machine\n");
        printf("3. View All Labs\n");
        printf("4. View Machines by Lab ID\n");
        printf("5. Search Machine by ID\n");
        printf("6. Delete Machine\n");
        printf("7. Back to Main Menu\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: addLab(); break;
            case 2: addMachine(); break;
            case 3: viewLabs(); break;
            case 4: viewMachinesByLab(); break;
            case 5: searchMachineById(); break;
            case 6: deleteMachine(); break;
            case 7: printf("Returning to main menu...\n"); break;
            default: printf("Invalid choice!\n");
        }
    } while (choice != 7);
}

void addLab() {
    struct Lab lab;
    FILE *fp = fopen("labs.dat", "ab");

    printf("Enter Lab ID: ");
    scanf("%d", &lab.labId);
    printf("Enter Lab Name: ");
    scanf(" %[^\n]", lab.labName);

    fwrite(&lab, sizeof(struct Lab), 1, fp);
    fclose(fp);

    printf("Lab added successfully!\n");
}

void viewLabs() {
    struct Lab lab;
    FILE *fp = fopen("labs.dat", "rb");

    if (fp == NULL) {
        printf("No labs found!\n");
        return;
    }

    printf("\n---- List of Labs ----\n");
    while (fread(&lab, sizeof(struct Lab), 1, fp)) {
        printf("Lab ID: %d | Lab Name: %s\n", lab.labId, lab.labName);
    }

    fclose(fp);
}

void addMachine() {
    struct Machine machine;
    FILE *fp = fopen("machines.dat", "ab");

    printf("Enter Machine ID: ");
    scanf("%d", &machine.machineId);
    printf("Enter Lab ID: ");
    scanf("%d", &machine.labId);
    printf("Enter Machine Status (Available/In Use/Maintenance): ");
    scanf(" %[^\n]", machine.status);
    printf("Enter Machine Specification: ");
    scanf(" %[^\n]", machine.specification);

    fwrite(&machine, sizeof(struct Machine), 1, fp);
    fclose(fp);

    printf("Machine added successfully!\n");
}

void viewMachinesByLab() {
    int labId;
    struct Machine machine;
    FILE *fp = fopen("machines.dat", "rb");

    if (fp == NULL) {
        printf("No machines found!\n");
        return;
    }

    printf("Enter Lab ID to view machines: ");
    scanf("%d", &labId);

    printf("\n---- Machines in Lab ID %d ----\n", labId);
    while (fread(&machine, sizeof(struct Machine), 1, fp)) {
        if (machine.labId == labId) {
            printf("Machine ID: %d | Status: %s | Spec: %s\n", 
                   machine.machineId, machine.status, machine.specification);
        }
    }

    fclose(fp);
}

void searchMachineById() {
    int id, found = 0;
    struct Machine machine;
    FILE *fp = fopen("machines.dat", "rb");

    if (fp == NULL) {
        printf("No machines found!\n");
        return;
    }

    printf("Enter Machine ID to search: ");
    scanf("%d", &id);

    while (fread(&machine, sizeof(struct Machine), 1, fp)) {
        if (machine.machineId == id) {
            printf("Found Machine:\nID: %d | Lab ID: %d | Status: %s | Spec: %s\n", 
                   machine.machineId, machine.labId, machine.status, machine.specification);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Machine not found!\n");
    }

    fclose(fp);
}

void deleteMachine() {
    int id;
    struct Machine machine;
    FILE *fp = fopen("machines.dat", "rb");
    
    if (fp == NULL) {
        printf("No machines found!\n");
        return;
    }
    
    FILE *temp = fopen("temp.dat", "wb");

    printf("Enter Machine ID to delete: ");
    scanf("%d", &id);

    int found = 0;
    while (fread(&machine, sizeof(struct Machine), 1, fp)) {
        if (machine.machineId != id) {
            fwrite(&machine, sizeof(struct Machine), 1, temp);
        } else {
            found = 1;
        }
    }

    fclose(fp);
    fclose(temp);

    remove("machines.dat");
    rename("temp.dat", "machines.dat");

    if (found)
        printf("Machine deleted successfully.\n");
    else
        printf("Machine ID not found.\n");
}

// Library Management Functions
int authenticate() {
    char password[50];
    int attempts = 3;
    
    while(attempts > 0) {
        printf("Enter library password (attempts left: %d): ", attempts);
        scanf("%s", password);
        
        if(strcmp(password, PASSWORD) == 0) {
            return 1;
        } else {
            printf("Incorrect password!\n");
            attempts--;
        }
    }
    return 0;
}

void libraryMenu() {
    if(!authenticate()) {
        printf("Access denied to Library Management System.\n");
        return;
    }

    int choice;
    do {
        printf("\n=== LIBRARY MANAGEMENT SYSTEM ===\n");
        printf("1. Add New Book\n");
        printf("2. Search Books\n");
        printf("3. Issue Book\n");
        printf("4. Return Book\n");
        printf("5. View Current Issues\n");
        printf("6. Generate Reports\n");
        printf("7. Back to Main Menu\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar(); // Clear input buffer

        switch(choice) {
            case 1: addBook(); break;
            case 2: searchBook(); break;
            case 3: issueBook(); break;
            case 4: returnBook(); break;
            case 5: viewIssues(); break;
            case 6: generateReports(); break;
            case 7: break;
            default: printf("Invalid choice. Please try again.\n");
        }
    } while(choice != 7);
}

void addBook() {
    if(bookCount >= MAX_BOOKS) {
        printf("Library capacity reached! Cannot add more books.\n");
        return;
    }

    printf("\nEnter Book Details:\n");
    books[bookCount].id = 1000 + bookCount;

    printf("Title: ");
    fgets(books[bookCount].title, sizeof(books[bookCount].title), stdin);
    books[bookCount].title[strcspn(books[bookCount].title, "\n")] = '\0';

    printf("Author: ");
    fgets(books[bookCount].author, sizeof(books[bookCount].author), stdin);
    books[bookCount].author[strcspn(books[bookCount].author, "\n")] = '\0';

    printf("Publisher: ");
    fgets(books[bookCount].publisher, sizeof(books[bookCount].publisher), stdin);
    books[bookCount].publisher[strcspn(books[bookCount].publisher, "\n")] = '\0';

    printf("Year: ");
    scanf("%d", &books[bookCount].year);

    printf("Number of copies: ");
    scanf("%d", &books[bookCount].copies);

    books[bookCount].available = books[bookCount].copies;

    printf("Category: ");
    getchar(); // Clear buffer
    fgets(books[bookCount].category, sizeof(books[bookCount].category), stdin);
    books[bookCount].category[strcspn(books[bookCount].category, "\n")] = '\0';

    bookCount++;
    printf("Book added successfully!\n");
}

void searchBook() {
    if(bookCount == 0) {
        printf("No books available in the library.\n");
        return;
    }

    int choice;
    printf("\nSearch Books By:\n");
    printf("1. Title\n");
    printf("2. Author\n");
    printf("3. Category\n");
    printf("4. ID\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
    getchar(); // Clear buffer

    char searchTerm[100];
    printf("Enter search term: ");
    fgets(searchTerm, sizeof(searchTerm), stdin);
    searchTerm[strcspn(searchTerm, "\n")] = '\0';

    // Convert search term to lowercase for case-insensitive search
    for(int i = 0; searchTerm[i]; i++) {
        searchTerm[i] = tolower(searchTerm[i]);
    }

    bool found = false;
    for(int i = 0; i < bookCount; i++) {
        char field[100];
        
        switch(choice) {
            case 1: strcpy(field, books[i].title); break;
            case 2: strcpy(field, books[i].author); break;
            case 3: strcpy(field, books[i].category); break;
            case 4: 
                sprintf(field, "%d", books[i].id);
                break;
            default:
                printf("Invalid choice.\n");
                return;
        }

        // Convert field to lowercase
        for(int j = 0; field[j]; j++) {
            field[j] = tolower(field[j]);
        }

        if(strstr(field, searchTerm)) {
            displayBook(i);
            found = true;
        }
    }

    if(!found) {
        printf("No matching books found.\n");
    }
}

void displayBook(int index) {
    printf("\nBook ID: %d\n", books[index].id);
    printf("Title: %s\n", books[index].title);
    printf("Author: %s\n", books[index].author);
    printf("Publisher: %s\n", books[index].publisher);
    printf("Year: %d\n", books[index].year);
    printf("Category: %s\n", books[index].category);
    printf("Total copies: %d\n", books[index].copies);
    printf("Available copies: %d\n", books[index].available);
    printf("---------------------------------\n");
}

void issueBook() {
    if(bookCount == 0) {
        printf("No books available to issue.\n");
        return;
    }

    if(libStudentCount == 0) {
        printf("No students registered in the system.\n");
        return;
    }

    if(issueCount >= MAX_ISSUES) {
        printf("Maximum issues limit reached.\n");
        return;
    }

    printf("\nEnter Book ID to issue: ");
    int bookId;
    scanf("%d", &bookId);

    // Find the book
    int bookIndex = -1;
    for(int i = 0; i < bookCount; i++) {
        if(books[i].id == bookId) {
            bookIndex = i;
            break;
        }
    }

    if(bookIndex == -1) {
        printf("Book with ID %d not found.\n", bookId);
        return;
    }

    if(books[bookIndex].available <= 0) {
        printf("No copies of this book are currently available.\n");
        return;
    }

    printf("\nEnter Student Roll Number: ");
    char rollNumber[15];
    scanf("%s", rollNumber);

    // Verify student
    bool studentExists = false;
    for(int i = 0; i < libStudentCount; i++) {
        if(strcmp(libStudents[i].roll_number, rollNumber) == 0) {
            studentExists = true;
            break;
        }
    }

    if(!studentExists) {
        printf("Student with roll number %s not found.\n", rollNumber);
        return;
    }

    // Check if student already has this book issued
    for(int i = 0; i < issueCount; i++) {
        if(strcmp(issues[i].roll_number, rollNumber) == 0 && 
           issues[i].book_id == bookId && 
           strcmp(issues[i].return_date, "") == 0) {
            printf("This student already has this book issued.\n");
            return;
        }
    }

    // Get current date and calculate due date (14 days later)
    char currentDate[20], dueDate[20];
    getCurrentDate(currentDate);
    calculateDueDate(currentDate, dueDate);

    // Create issue record
    issues[issueCount].book_id = bookId;
    strcpy(issues[issueCount].roll_number, rollNumber);
    strcpy(issues[issueCount].issue_date, currentDate);
    strcpy(issues[issueCount].due_date, dueDate);
    strcpy(issues[issueCount].return_date, "");
    issues[issueCount].fine = 0.0;

    // Update book availability
    books[bookIndex].available--;

    issueCount++;
    printf("\nBook issued successfully!\n");
    printf("Issue Date: %s\n", currentDate);
    printf("Due Date: %s\n", dueDate);
}

void returnBook() {
    if(issueCount == 0) {
        printf("No books currently issued.\n");
        return;
    }

    printf("\nEnter Book ID to return: ");
    int bookId;
    scanf("%d", &bookId);

    printf("Enter Student Roll Number: ");
    char rollNumber[15];
    scanf("%s", rollNumber);

    // Find the issue
    int issueIndex = -1;
    for(int i = 0; i < issueCount; i++) {
        if(issues[i].book_id == bookId && 
           strcmp(issues[i].roll_number, rollNumber) == 0 &&
           strcmp(issues[i].return_date, "") == 0) {
            issueIndex = i;
            break;
        }
    }

    if(issueIndex == -1) {
        printf("No active issue found for this book and student.\n");
        return;
    }

    // Get return date and calculate fine if any
    char returnDate[20];
    getCurrentDate(returnDate);
    strcpy(issues[issueIndex].return_date, returnDate);

    float fine = calculateFine(issues[issueIndex].due_date, returnDate);
    issues[issueIndex].fine = fine;

    // Update book availability
    for(int i = 0; i < bookCount; i++) {
        if(books[i].id == bookId) {
            books[i].available++;
            break;
        }
    }

    printf("\nBook returned successfully!\n");
    printf("Return Date: %s\n", returnDate);
    if(fine > 0) {
        printf("Fine: $%.2f (for late return)\n", fine);
    } else {
        printf("No fine. Book returned on time.\n");
    }
}

void viewIssues() {
    if(issueCount == 0) {
        printf("No books currently issued.\n");
        return;
    }

    printf("\n=== CURRENTLY ISSUED BOOKS ===\n");
    printf("Book ID\tStudent Roll\tIssue Date\tDue Date\n");
    printf("------------------------------------------------\n");

    for(int i = 0; i < issueCount; i++) {
        if(strcmp(issues[i].return_date, "") == 0) {
            printf("%d\t%s\t%s\t%s\n", 
                   issues[i].book_id, 
                   issues[i].roll_number,
                   issues[i].issue_date,
                   issues[i].due_date);
        }
    }
}

void generateReports() {
    int choice;
    printf("\nGenerate Report:\n");
    printf("1. All Books\n");
    printf("2. Available Books\n");
    printf("3. Issued Books\n");
    printf("4. Overdue Books\n");
    printf("5. Back\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    char currentDate[20];
    getCurrentDate(currentDate);

    switch(choice) {
        case 1:
            printf("\n=== ALL BOOKS IN LIBRARY ===\n");
            printf("ID\tTitle\t\tAuthor\t\tAvailable\n");
            printf("----------------------------------------\n");
            for(int i = 0; i < bookCount; i++) {
                printf("%d\t%s\t%s\t%d/%d\n", 
                       books[i].id, 
                       books[i].title,
                       books[i].author,
                       books[i].available,
                       books[i].copies);
            }
            break;
            
        case 2:
            printf("\n=== AVAILABLE BOOKS ===\n");
            printf("ID\tTitle\t\tAuthor\n");
            printf("--------------------------------\n");
            for(int i = 0; i < bookCount; i++) {
                if(books[i].available > 0) {
                    printf("%d\t%s\t%s\n", 
                           books[i].id, 
                           books[i].title,
                           books[i].author);
                }
            }
            break;
            
        case 3:
            printf("\n=== ISSUED BOOKS ===\n");
            printf("Book ID\tStudent\tIssue Date\tDue Date\n");
            printf("----------------------------------------\n");
            for(int i = 0; i < issueCount; i++) {
                if(strcmp(issues[i].return_date, "") == 0) {
                    printf("%d\t%s\t%s\t%s\n", 
                           issues[i].book_id,
                           issues[i].roll_number,
                           issues[i].issue_date,
                           issues[i].due_date);
                }
            }
            break;
            
        case 4:
            printf("\n=== OVERDUE BOOKS ===\n");
            printf("Book ID\tStudent\tDue Date\tDays Overdue\n");
            printf("----------------------------------------\n");
            for(int i = 0; i < issueCount; i++) {
                if(strcmp(issues[i].return_date, "") == 0 &&
                   strcmp(issues[i].due_date, currentDate) < 0) {
                    float fine = calculateFine(issues[i].due_date, currentDate);
                    printf("%d\t%s\t%s\t%.0f days\n", 
                           issues[i].book_id,
                           issues[i].roll_number,
                           issues[i].due_date,
                           fine/1.0); // $1 per day fine
                }
            }
            break;
            
        case 5:
            break;
            
        default:
            printf("Invalid choice.\n");
    }
}

void getCurrentDate(char *dateStr) {
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(dateStr, "%04d-%02d-%02d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
}

void calculateDueDate(const char *issueDate, char *dueDate) {
    // Parse the issue date
    int year, month, day;
    sscanf(issueDate, "%4d-%2d-%2d", &year, &month, &day);
    
    // Add 14 days to the issue date
    struct tm tm = {0};
    tm.tm_year = year - 1900;
    tm.tm_mon = month - 1;
    tm.tm_mday = day + 14;
    mktime(&tm); // Normalize the date
    
    // Format the due date
    sprintf(dueDate, "%04d-%02d-%02d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
}

float calculateFine(const char *dueDate, const char *returnDate) {
    // Parse the dates
    int dueYear, dueMonth, dueDay;
    int returnYear, returnMonth, returnDay;
    
    sscanf(dueDate, "%4d-%2d-%2d", &dueYear, &dueMonth, &dueDay);
    sscanf(returnDate, "%4d-%2d-%2d", &returnYear, &returnMonth, &returnDay);
    
    // Convert to time_t
    struct tm dueTm = {0};
    dueTm.tm_year = dueYear - 1900;
    dueTm.tm_mon = dueMonth - 1;
    dueTm.tm_mday = dueDay;
    time_t dueTime = mktime(&dueTm);
    
    struct tm returnTm = {0};
    returnTm.tm_year = returnYear - 1900;
    returnTm.tm_mon = returnMonth - 1;
    returnTm.tm_mday = returnDay;
    time_t returnTime = mktime(&returnTm);
    
    // Calculate difference in days
    double diff = difftime(returnTime, dueTime) / (60 * 60 * 24);
    
    if (diff <= 0) {
        return 0.0; // No fine if returned on or before due date
    }
    
    return diff * 1.0; // $1 per day fine
}

// Student Management Functions
void studentManagement() {
    int choice;
    do {
        printf("\nStudent Management:\n");
        printf("1. Add New Student\n");
        printf("2. View All Students\n");
        printf("3. Pay Fees\n");
        printf("4. View Fee Report\n");
        printf("5. Manage Attendance\n");
        printf("6. Manage Exam Marks\n");
        printf("7. View Attendance Report\n");
        printf("8. View Marks Report\n");
        printf("9. Back to Main Menu\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        
        switch(choice) {
            case 1:
                addStudent();
                break;
            case 2:
                viewStudents();
                break;
            case 3:
                payFees();
                break;
            case 4:
                viewFeeReport();
                break;
            case 5:
                manageAttendance();
                break;
            case 6:
                manageMarks();
                break;
            case 7:
                viewAttendanceReport();
                break;
            case 8:
                viewMarksReport();
                break;
            case 9:
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while(choice != 9);
}

void addStudent() {
    if(studentCount >= MAX_STUDENTS) {
        printf("Maximum student capacity reached!\n");
        return;
    }
    
    struct Student s;
    int quota_choice, course_choice, accommodation_choice;
    float base_fee = 0, course_fee = 0, accommodation_fee = 0;
    
    printf("\nEnter Student Details:\n");
    
    // Generate ID
    s.id = 1000 + studentCount;
    
    // Generate Roll Number (format: 24DNS1A000)
    snprintf(s.roll_number, sizeof(s.roll_number), "24DNS1A%03d", studentCount + 1);
    
    // Basic details
    printf("Name: ");
    getchar(); // Clear input buffer
    fgets(s.name, sizeof(s.name), stdin);
    s.name[strcspn(s.name, "\n")] = '\0';
    
    printf("Father's Name: ");
    fgets(s.father_name, sizeof(s.father_name), stdin);
    s.father_name[strcspn(s.father_name, "\n")] = '\0';
    
    printf("Father's Phone Number: ");
    fgets(s.father_phone, sizeof(s.father_phone), stdin);
    s.father_phone[strcspn(s.father_phone, "\n")] = '\0';
    
    printf("Student's Phone Number: ");
    fgets(s.student_phone, sizeof(s.student_phone), stdin);
    s.student_phone[strcspn(s.student_phone, "\n")] = '\0';
    
    printf("Aadhar Number: ");
    fgets(s.aadhar_number, sizeof(s.aadhar_number), stdin);
    s.aadhar_number[strcspn(s.aadhar_number, "\n")] = '\0';
    
    // Quota selection
    printf("\nSelect Quota:\n");
    printf("1. RTF (Fee: 40000)\n");
    printf("2. Management (Fee: 100000)\n");
    printf("Enter choice (1-2): ");
    scanf("%d", &quota_choice);
    
    switch(quota_choice) {
        case 1:
            strcpy(s.quota, "RTF");
            base_fee = 40000;
            break;
        case 2:
            strcpy(s.quota, "Management");
            base_fee = 100000;
            break;
        default:
            printf("Invalid choice. Setting to RTF by default.\n");
            strcpy(s.quota, "RTF");
            base_fee = 40000;
    }
    
    // Course selection
    printf("\nSelect Course:\n");
    printf("1. CSE (Fee: 20000)\n");
    printf("2. ECE (Fee: 15000)\n");
    printf("3. Civil (Fee: 10000)\n");
    printf("4. Mechanical (Fee: 10000)\n");
    printf("Enter choice (1-4): ");
    scanf("%d", &course_choice);
    
    switch(course_choice) {
        case 1:
            strcpy(s.course, "CSE");
            course_fee = 20000;
            break;
        case 2:
            strcpy(s.course, "ECE");
            course_fee = 15000;
            break;
        case 3:
            strcpy(s.course, "Civil");
            course_fee = 10000;
            break;
        case 4:
            strcpy(s.course, "Mechanical");
            course_fee = 10000;
            break;
        default:
            printf("Invalid choice. Setting to CSE by default.\n");
            strcpy(s.course, "CSE");
            course_fee = 20000;
    }
    
    // Accommodation selection
    printf("\nSelect Accommodation:\n");
    printf("1. Bus (Fee: 20000)\n");
    printf("2. Hostel (Fee: 80000)\n");
    printf("Enter choice (1-2): ");
    scanf("%d", &accommodation_choice);
    
    switch(accommodation_choice) {
        case 1:
            strcpy(s.accommodation, "Bus");
            accommodation_fee = 20000;
            break;
        case 2:
            strcpy(s.accommodation, "Hostel");
            accommodation_fee = 80000;
            break;
        default:
            printf("Invalid choice. Setting to Bus by default.\n");
            strcpy(s.accommodation, "Bus");
            accommodation_fee = 20000;
    }
    
    // Calculate total fees
    s.total_fees = base_fee + course_fee + accommodation_fee;
    s.fee_paid = 0;
    s.fee_balance = s.total_fees;
    strcpy(s.last_payment_date, "Not paid yet");
    
    // Initialize attendance and marks
    printf("\nEnter number of subjects (max %d): ", MAX_SUBJECTS);
    scanf("%d", &s.num_subjects);
    
    if(s.num_subjects > MAX_SUBJECTS || s.num_subjects <= 0) {
        printf("Invalid number of subjects. Setting to 5 by default.\n");
        s.num_subjects = 5;
    }
    
    getchar(); // Clear input buffer
    for(int i = 0; i < s.num_subjects; i++) {
        printf("Enter subject %d name: ", i+1);
        fgets(s.subjects[i], sizeof(s.subjects[i]), stdin);
        s.subjects[i][strcspn(s.subjects[i], "\n")] = '\0';
        s.attendance[i] = 0; // Initialize to 0%
        s.marks[i] = 0.0;    // Initialize to 0 marks
    }
    
    // Add to students array
    students[studentCount] = s;
    studentCount++;
    
    // Also add to library students if not already present
    bool exists = false;
    for(int i = 0; i < libStudentCount; i++) {
        if(strcmp(libStudents[i].roll_number, s.roll_number) == 0) {
            exists = true;
            break;
        }
    }
    
    if(!exists && libStudentCount < MAX_STUDENTS) {
        strcpy(libStudents[libStudentCount].roll_number, s.roll_number);
        strcpy(libStudents[libStudentCount].name, s.name);
        libStudentCount++;
    }
    
    printf("\nStudent added successfully!\n");
    printf("Generated Roll Number: %s\n", s.roll_number);
    
    // Generate and display bill
    generateBill(s);
}

void generateBill(struct Student s) {
    printf("\n=== FEE BILL ===\n");
    printf("============================================\n");
    printf("Roll Number: %s\n", s.roll_number);
    printf("Name: %s\n", s.name);
    printf("Father's Name: %s\n", s.father_name);
    printf("Aadhar Number: %s\n", s.aadhar_number);
    printf("Course: %s\n", s.course);
    printf("Quota: %s\n", s.quota);
    printf("Accommodation: %s\n", s.accommodation);
    printf("--------------------------------------------\n");
    printf("Fee Details:\n");
    
    // Determine base fee based on quota
    float base_fee = (strcmp(s.quota, "RTF") == 0) ? 40000 : 100000;
    printf("- %s Quota Fee: %.2f\n", s.quota, base_fee);
    
    // Determine course fee
    float course_fee = 0;
    if(strcmp(s.course, "CSE") == 0) course_fee = 20000;
    else if(strcmp(s.course, "ECE") == 0) course_fee = 15000;
    else course_fee = 10000;
    printf("- %s Course Fee: %.2f\n", s.course, course_fee);
    
    // Determine accommodation fee
    float accommodation_fee = (strcmp(s.accommodation, "Bus") == 0) ? 20000 : 80000;
    printf("- %s Fee: %.2f\n", s.accommodation, accommodation_fee);
    
    printf("--------------------------------------------\n");
    printf("TOTAL FEES: %.2f\n", s.total_fees);
    printf("FEES PAID: %.2f\n", s.fee_paid);
    printf("BALANCE DUE: %.2f\n", s.fee_balance);
    printf("LAST PAYMENT DATE: %s\n", s.last_payment_date);
    printf("============================================\n");
}

void viewStudents() {
    if(studentCount == 0) {
        printf("No student records found.\n");
        return;
    }
    
    printf("\n=== Student Records ===\n");
    printf("Roll No.\tName\t\tCourse\t\tQuota\t\tTotal Fees\tPaid\tBalance\n");
    printf("----------------------------------------------------------------------------------------\n");
    for(int i = 0; i < studentCount; i++) {
        printf("%s\t%s\t\t%s\t\t%s\t\t%.2f\t%.2f\t%.2f\n", 
               students[i].roll_number, students[i].name, 
               students[i].course, students[i].quota, 
               students[i].total_fees, students[i].fee_paid,
               students[i].fee_balance);
    }
}

void payFees() {
    if(studentCount == 0) {
        printf("No student records found.\n");
        return;
    }
    
    char rollNumber[15];
    float amount;
    char dateStr[20];
    
    printf("\nEnter Student Roll Number: ");
    getchar(); // Clear input buffer
    fgets(rollNumber, sizeof(rollNumber), stdin);
    rollNumber[strcspn(rollNumber, "\n")] = '\0';
    
    int found = 0;
    for(int i = 0; i < studentCount; i++) {
        if(strcmp(students[i].roll_number, rollNumber) == 0) {
            found = 1;
            
            printf("\nStudent Found:\n");
            printf("Name: %s\n", students[i].name);
            printf("Course: %s\n", students[i].course);
            printf("Total Fees: %.2f\n", students[i].total_fees);
            printf("Fees Paid: %.2f\n", students[i].fee_paid);
            printf("Balance Due: %.2f\n", students[i].fee_balance);
            
            printf("\nEnter Amount to Pay: ");
            scanf("%f", &amount);
            
            if(amount <= 0) {
                printf("Invalid amount. Payment cancelled.\n");
                return;
            }
            
            if(amount > students[i].fee_balance) {
                printf("Amount exceeds balance due. Payment cancelled.\n");
                return;
            }
            
            // Update payment details
            students[i].fee_paid += amount;
            students[i].fee_balance = students[i].total_fees - students[i].fee_paid;
            getCurrentDateCommon(dateStr);
            strcpy(students[i].last_payment_date, dateStr);
            
            printf("\nPayment successful!\n");
            printf("Updated Balance: %.2f\n", students[i].fee_balance);
            printf("Payment Date: %s\n", dateStr);
            
            // Generate receipt
            printf("\n=== PAYMENT RECEIPT ===\n");
            printf("Roll Number: %s\n", students[i].roll_number);
            printf("Name: %s\n", students[i].name);
            printf("Amount Paid: %.2f\n", amount);
            printf("Payment Date: %s\n", dateStr);
            printf("Remaining Balance: %.2f\n", students[i].fee_balance);
            printf("=========================\n");
            
            break;
        }
    }
    
    if(!found) {
        printf("Student with Roll Number %s not found.\n", rollNumber);
    }
}

void viewFeeReport() {
    if(studentCount == 0) {
        printf("No student records found.\n");
        return;
    }
    
    printf("\n=== FEE PAYMENT REPORT ===\n");
    printf("Roll No.\tName\t\tCourse\t\tTotal Fees\tPaid\tBalance\tLast Payment\n");
    printf("----------------------------------------------------------------------------------------\n");
    for(int i = 0; i < studentCount; i++) {
        printf("%s\t%s\t\t%s\t\t%.2f\t%.2f\t%.2f\t%s\n", 
               students[i].roll_number, students[i].name, 
               students[i].course, students[i].total_fees, 
               students[i].fee_paid, students[i].fee_balance,
               students[i].last_payment_date);
    }
    
    // Calculate summary
    float total_fees = 0, total_paid = 0, total_balance = 0;
    for(int i = 0; i < studentCount; i++) {
        total_fees += students[i].total_fees;
        total_paid += students[i].fee_paid;
        total_balance += students[i].fee_balance;
    }
    
    printf("\nSUMMARY:\n");
    printf("Total Students: %d\n", studentCount);
    printf("Total Fees Expected: %.2f\n", total_fees);
    printf("Total Fees Collected: %.2f\n", total_paid);
    printf("Total Outstanding: %.2f\n", total_balance);
    printf("Collection Percentage: %.2f%%\n", (total_paid/total_fees)*100);
}

void manageAttendance() {
    if(studentCount == 0) {
        printf("No student records found.\n");
        return;
    }
    
    char rollNumber[15];
    printf("\nEnter Student Roll Number: ");
    getchar();
    fgets(rollNumber, sizeof(rollNumber), stdin);
    rollNumber[strcspn(rollNumber, "\n")] = '\0';
    
    int found = 0;
    for(int i = 0; i < studentCount; i++) {
        if(strcmp(students[i].roll_number, rollNumber) == 0) {
            found = 1;
            
            printf("\nStudent Found:\n");
            printf("Name: %s\n", students[i].name);
            printf("Course: %s\n", students[i].course);
            printf("Number of Subjects: %d\n", students[i].num_subjects);
            
            printf("\nCurrent Attendance:\n");
            for(int j = 0; j < students[i].num_subjects; j++) {
                printf("%d. %s: %d%%\n", j+1, students[i].subjects[j], students[i].attendance[j]);
            }
            
            printf("\nUpdate Attendance (Enter percentage for each subject):\n");
            for(int j = 0; j < students[i].num_subjects; j++) {
                printf("%s: ", students[i].subjects[j]);
                scanf("%d", &students[i].attendance[j]);
                
                // Validate attendance percentage
                if(students[i].attendance[j] < 0) students[i].attendance[j] = 0;
                if(students[i].attendance[j] > 100) students[i].attendance[j] = 100;
            }
            
            printf("\nAttendance updated successfully!\n");
            break;
        }
    }
    
    if(!found) {
        printf("Student with Roll Number %s not found.\n", rollNumber);
    }
}

void manageMarks() {
    if(studentCount == 0) {
        printf("No student records found.\n");
        return;
    }
    
    char rollNumber[15];
    printf("\nEnter Student Roll Number: ");
    getchar();
    fgets(rollNumber, sizeof(rollNumber), stdin);
    rollNumber[strcspn(rollNumber, "\n")] = '\0';
    
    int found = 0;
    for(int i = 0; i < studentCount; i++) {
        if(strcmp(students[i].roll_number, rollNumber) == 0) {
            found = 1;
            
            printf("\nStudent Found:\n");
            printf("Name: %s\n", students[i].name);
            printf("Course: %s\n", students[i].course);
            printf("Number of Subjects: %d\n", students[i].num_subjects);
            
            printf("\nCurrent Marks:\n");
            for(int j = 0; j < students[i].num_subjects; j++) {
                printf("%d. %s: %.2f/100\n", j+1, students[i].subjects[j], students[i].marks[j]);
            }
            
            printf("\nUpdate Marks (Enter marks out of 100 for each subject):\n");
            for(int j = 0; j < students[i].num_subjects; j++) {
                printf("%s: ", students[i].subjects[j]);
                scanf("%f", &students[i].marks[j]);
                
                // Validate marks
                if(students[i].marks[j] < 0) students[i].marks[j] = 0;
                if(students[i].marks[j] > 100) students[i].marks[j] = 100;
            }
            
            printf("\nMarks updated successfully!\n");
            break;
        }
    }
    
    if(!found) {
        printf("Student with Roll Number %s not found.\n", rollNumber);
    }
}

void viewAttendanceReport() {
    if(studentCount == 0) {
        printf("No student records found.\n");
        return;
    }
    
    printf("\n=== ATTENDANCE REPORT ===\n");
    
    for(int i = 0; i < studentCount; i++) {
        printf("\nRoll No.: %s\n", students[i].roll_number);
        printf("Name: %s\n", students[i].name);
        printf("Course: %s\n", students[i].course);
        printf("Subjects and Attendance:\n");
        
        for(int j = 0; j < students[i].num_subjects; j++) {
            printf("- %s: %d%%\n", students[i].subjects[j], students[i].attendance[j]);
        }
        
        // Calculate average attendance
        int total_attendance = 0;
        for(int j = 0; j < students[i].num_subjects; j++) {
            total_attendance += students[i].attendance[j];
        }
        float avg_attendance = (float)total_attendance / students[i].num_subjects;
        
        printf("Average Attendance: %.2f%%\n", avg_attendance);
        printf("---------------------------------\n");
    }
}

void viewMarksReport() {
    if(studentCount == 0) {
        printf("No student records found.\n");
        return;
    }
    
    printf("\n=== EXAM MARKS REPORT ===\n");
    
    for(int i = 0; i < studentCount; i++) {
        printf("\nRoll No.: %s\n", students[i].roll_number);
        printf("Name: %s\n", students[i].name);
        printf("Course: %s\n", students[i].course);
        printf("Subjects and Marks:\n");
        
        for(int j = 0; j < students[i].num_subjects; j++) {
            printf("- %s: %.2f/100\n", students[i].subjects[j], students[i].marks[j]);
        }
        
        // Calculate average marks
        float total_marks = 0;
        for(int j = 0; j < students[i].num_subjects; j++) {
            total_marks += students[i].marks[j];
        }
        float avg_marks = total_marks / students[i].num_subjects;
        
        printf("Average Marks: %.2f/100\n", avg_marks);
        
        // Calculate percentage and grade
        float percentage = avg_marks;
        char grade[3];
        if(percentage >= 90) strcpy(grade, "A+");
        else if(percentage >= 80) strcpy(grade, "A");
        else if(percentage >= 70) strcpy(grade, "B+");
        else if(percentage >= 60) strcpy(grade, "B");
        else if(percentage >= 50) strcpy(grade, "C");
        else if(percentage >= 40) strcpy(grade, "D");
        else strcpy(grade, "F");
        
        printf("Percentage: %.2f%%\n", percentage);
        printf("Grade: %s\n", grade);
        printf("---------------------------------\n");
    }
}

// Faculty Management Functions
void facultyManagement() {
    int choice;
    do {
        printf("\nFaculty Management:\n");
        printf("1. Add New Faculty\n");
        printf("2. View All Faculty\n");
        printf("3. Pay Salary\n");
        printf("4. Salary Report\n");
        printf("5. Back to Main Menu\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        
        switch(choice) {
            case 1:
                addFaculty();
                break;
            case 2:
                viewFaculty();
                break;
            case 3:
                paySalary();
                break;
            case 4:
                salaryReport();
                break;
            case 5:
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while(choice != 5);
}

void addFaculty() {
    if(facultyCount >= MAX_FACULTY) {
        printf("Maximum faculty capacity reached!\n");
        return;
    }
    
    struct Faculty f;
    char dateStr[20];
    
    printf("\nEnter Faculty Details:\n");
    
    // Generate ID and code
    f.id = 2000 + facultyCount;
    generateFacultyCode(f.faculty_code, facultyCount + 1);
    
    // Basic details
    printf("Name: ");
    getchar(); // Clear input buffer
    fgets(f.name, sizeof(f.name), stdin);
    f.name[strcspn(f.name, "\n")] = '\0';
    
    printf("Degree: ");
    fgets(f.degree, sizeof(f.degree), stdin);
    f.degree[strcspn(f.degree, "\n")] = '\0';
    
    printf("Phone Number: ");
    fgets(f.phone, sizeof(f.phone), stdin);
    f.phone[strcspn(f.phone, "\n")] = '\0';
    
    printf("Subjects to teach (comma separated): ");
    fgets(f.subjects, sizeof(f.subjects), stdin);
    f.subjects[strcspn(f.subjects, "\n")] = '\0';
    
    // Salary components
    printf("\nEnter Salary Details:\n");
    printf("Basic Salary: ");
    scanf("%f", &f.basic_salary);
    
    printf("HRA (%% of Basic): ");
    float hra_percent;
    scanf("%f", &hra_percent);
    f.hra = f.basic_salary * (hra_percent / 100);
    
    printf("DA (%% of Basic): ");
    float da_percent;
    scanf("%f", &da_percent);
    f.da = f.basic_salary * (da_percent / 100);
    
    printf("TA (%% of Basic): ");
    float ta_percent;
    scanf("%f", &ta_percent);
    f.ta = f.basic_salary * (ta_percent / 100);
    
    printf("Deductions: ");
    scanf("%f", &f.deductions);
    
    // Calculate net salary
    calculateSalary(&f);
    
    printf("Room Number: ");
    getchar(); // Clear input buffer
    fgets(f.room_number, sizeof(f.room_number), stdin);
    f.room_number[strcspn(f.room_number, "\n")] = '\0';
    
    // Set dates
    getCurrentDateCommon(dateStr);
    strcpy(f.joining_date, dateStr);
    strcpy(f.last_salary_date, "Not paid yet");
    
    // Add to faculty array
    faculty[facultyCount] = f;
    facultyCount++;
    
    printf("\nFaculty member added successfully!\n");
    printf("Generated Faculty Code: %s\n", f.faculty_code);
    
    // Display faculty details
    printf("\n=== FACULTY DETAILS ===\n");
    printf("Faculty Code: %s\n", f.faculty_code);
    printf("Name: %s\n", f.name);
    printf("Degree: %s\n", f.degree);
    printf("Phone: %s\n", f.phone);
    printf("Subjects: %s\n", f.subjects);
    printf("Basic Salary: %.2f\n", f.basic_salary);
    printf("Net Salary: %.2f\n", f.net_salary);
    printf("Room Number: %s\n", f.room_number);
    printf("Joining Date: %s\n", f.joining_date);
    printf("=========================\n");
}

void calculateSalary(struct Faculty *f) {
    f->net_salary = f->basic_salary + f->hra + f->da + f->ta - f->deductions;
}

void viewFaculty() {
    if(facultyCount == 0) {
        printf("No faculty records found.\n");
        return;
    }
    
    printf("\n=== FACULTY DIRECTORY ===\n");
    printf("Code\t\tName\t\tDegree\t\tBasic Salary\tNet Salary\tLast Paid\n");
    printf("==========================================================================\n");
    for(int i = 0; i < facultyCount; i++) {
        printf("%s\t%s\t\t%s\t\t%.2f\t\t%.2f\t\t%s\n", 
               faculty[i].faculty_code, faculty[i].name, 
               faculty[i].degree, faculty[i].basic_salary,
               faculty[i].net_salary, faculty[i].last_salary_date);
    }
}

void paySalary() {
    if(facultyCount == 0) {
        printf("No faculty records found.\n");
        return;
    }
    
    char facultyCode[15];
    char dateStr[20];
    
    printf("\nEnter Faculty Code: ");
    getchar(); // Clear input buffer
    fgets(facultyCode, sizeof(facultyCode), stdin);
    facultyCode[strcspn(facultyCode, "\n")] = '\0';
    
    int found = 0;
    for(int i = 0; i < facultyCount; i++) {
        if(strcmp(faculty[i].faculty_code, facultyCode) == 0) {
            found = 1;
            
            printf("\nFaculty Found:\n");
            printf("Name: %s\n", faculty[i].name);
            printf("Faculty Code: %s\n", faculty[i].faculty_code);
            printf("Basic Salary: %.2f\n", faculty[i].basic_salary);
            printf("Net Salary: %.2f\n", faculty[i].net_salary);
            printf("Last Salary Date: %s\n", faculty[i].last_salary_date);
            
            printf("\nProcess salary payment? (Y/N): ");
            char confirm;
            scanf(" %c", &confirm);
            
            if(toupper(confirm) == 'Y') {
                getCurrentDateCommon(dateStr);
                strcpy(faculty[i].last_salary_date, dateStr);
                
                printf("\nSalary paid successfully!\n");
                printf("Payment Date: %s\n", dateStr);
                
                // Generate salary slip
                salarySlip(faculty[i]);
            } else {
                printf("Salary payment cancelled.\n");
            }
            
            break;
        }
    }
    
    if(!found) {
        printf("Faculty with code %s not found.\n", facultyCode);
    }
}

void salarySlip(struct Faculty f) {
    printf("\n=== SALARY SLIP ===\n");
    printf("============================================\n");
    printf("Faculty Code: %s\n", f.faculty_code);
    printf("Name: %s\n", f.name);
    printf("Joining Date: %s\n", f.joining_date);
    printf("Payment Date: %s\n", f.last_salary_date);
    printf("--------------------------------------------\n");
    printf("Salary Components:\n");
    printf("Basic Salary: %.2f\n", f.basic_salary);
    printf("HRA: %.2f\n", f.hra);
    printf("DA: %.2f\n", f.da);
    printf("TA: %.2f\n", f.ta);
    printf("Deductions: %.2f\n", f.deductions);
    printf("--------------------------------------------\n");
    printf("NET SALARY: %.2f\n", f.net_salary);
    printf("============================================\n");
}

void salaryReport() {
    if(facultyCount == 0) {
        printf("No faculty records found.\n");
        return;
    }
    
    printf("\n=== SALARY REPORT ===\n");
    printf("Code\t\tName\t\tBasic\t\tNet\tLast Paid\tStatus\n");
    printf("==================================================================\n");
    
    char currentDate[20];
    getCurrentDateCommon(currentDate);
    
    for(int i = 0; i < facultyCount; i++) {
        char status[20];
        if(strcmp(faculty[i].last_salary_date, "Not paid yet") == 0) {
            strcpy(status, "Pending");
        } else if(strcmp(faculty[i].last_salary_date, currentDate) == 0) {
            strcpy(status, "Paid Today");
        } else {
            strcpy(status, "Paid");
        }
        
        printf("%s\t%s\t\t%.2f\t%.2f\t%s\t%s\n", 
               faculty[i].faculty_code, faculty[i].name,
               faculty[i].basic_salary, faculty[i].net_salary,
               faculty[i].last_salary_date, status);
    }
    
    // Calculate summary
    float total_basic = 0, total_net = 0;
    int paid_count = 0;
    
    for(int i = 0; i < facultyCount; i++) {
        total_basic += faculty[i].basic_salary;
        total_net += faculty[i].net_salary;
        if(strcmp(faculty[i].last_salary_date, "Not paid yet") != 0) {
            paid_count++;
        }
    }
    
    printf("\nSUMMARY:\n");
    printf("Total Faculty: %d\n", facultyCount);
    printf("Total Basic Salary: %.2f\n", total_basic);
    printf("Total Net Salary: %.2f\n", total_net);
    printf("Total Deductions: %.2f\n", total_basic - total_net);
    printf("Faculty Paid: %d\n", paid_count);
    printf("Faculty Pending: %d\n", facultyCount - paid_count);
    printf("============================================\n");
}

void generateFacultyCode(char *code, int count) {
    snprintf(code, 15, "24NSD1A%03d", count);
}

void getCurrentDateCommon(char *dateStr) {
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(dateStr, "%02d/%02d/%04d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
}

// Main program
int main() {
    // Initialize with sample data for Library Management
    strcpy(libStudents[0].roll_number, "24DNS1A001");
    strcpy(libStudents[0].name, "John Doe");
    libStudentCount++;
    
    strcpy(libStudents[1].roll_number, "24DNS1A002");
    strcpy(libStudents[1].name, "Jane Smith");
    libStudentCount++;

    // Sample book
    books[0].id = 1001;
    strcpy(books[0].title, "Introduction to Algorithms");
    strcpy(books[0].author, "Cormen");
    strcpy(books[0].publisher, "MIT Press");
    books[0].year = 2009;
    books[0].copies = 5;
    books[0].available = 5;
    strcpy(books[0].category, "Computer Science");
    bookCount++;

    int choice;
    do {
        printf("\n=== UNIVERSITY MANAGEMENT SYSTEM ===\n");
        printf("\n=== CREATED BY SAMPATH, NARENDRA, DAS ===\n\n");
        printf("1. Student Management System\n");
        printf("2. Faculty Management System\n");
        printf("3. lab Management Menu\n");
        printf("4. Library Management System\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch(choice) {
            case 1:
                studentManagement();
                break;
            case 2:
                facultyManagement();
                break;
            case 3:
                labManagementMenu();
                break;
            case 4:
                libraryMenu();
                break;
            case 5:
                printf("Exiting the program...\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while(choice != 5);

    return 0;
}